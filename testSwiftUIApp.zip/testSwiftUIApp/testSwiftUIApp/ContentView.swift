//
//  ContentView.swift
//  testSwiftUIApp
//
//  Created by Rishab Subodh Habbu on 29/02/24.
//

import SwiftUI

struct User: Identifiable {
    var name: String
    var expense: Double
    var id = UUID()
}

struct ContentView: View {
    
    @ObservedObject var splitsVM  = SplitsVM()

    var body: some View {
        NavigationView {
            GeometryReader { geometry in
                HStack {
                    VStack {
                        HStack {
                            Text("Add")
                                .frame(maxWidth: .infinity)
                            Text("View Balances")
                                .frame(maxWidth: .infinity)
                        }
                        // Add Expenses Tab
                        HStack {
                            Text("Expense: ")
                            TextField("Enter Expense", text: $splitsVM.expenseInfo)
                        }
                        HStack {
                            Text("Total: ")
                            TextField("Enter Expense", text: $splitsVM.expenseAmount)
                                .onChange(of: splitsVM.expenseAmount) {
                                    splitsVM.updateUserData()
                                }
                        }
                        
                        Text("Paid by")
                        TextField("Enter Payee Name", text: $splitsVM.payeeName)
                        VStack {
                            HStack {
                                Text("Participants:")
                                Button(action: {
                                    splitsVM.addParticipant()
                                }, label: {
                                    Image(systemName: "plus")
                                })
                            }
                            ForEach(0..<splitsVM.totalTextFields.count, id: \.self) { index in
                                TextField("Enter Person Name", text: $splitsVM.totalTextFields[index])
                                    .onChange(of: splitsVM.totalTextFields) {
                                        splitsVM.updateUserData()
                                    }
                            }
                        }
                        
                        Button(action: {
                            splitsVM.updateViewAllParticipants()
                        }, label: {
                            Text("Update")
                        })
                        // View Balances Tab
                        
                        ForEach(Array(splitsVM.copyParticipants.enumerated()), id: \.offset) { index, data in
                            NavigationLink(destination: SplitDetailsView(name: data.name, totalAmount: data.expense).environment(splitsVM), label: {
                                HStack {
                                    if data.name != "" {
                                        Text(data.name)
                                        Text("\(data.expense)")
                                    }
                                    
                                }
                            })
                            
                        }
                        
                    }
                }
            }
            .padding()
        }
        
    }
}

#Preview {
    ScrollView {
        ContentView()
    }
}


// Generic UI 2 Pages
