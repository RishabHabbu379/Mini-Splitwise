//
//  SplitDetailsView.swift
//  testSwiftUIApp
//
//  Created by Rishab Subodh Habbu on 29/02/24.
//

import SwiftUI

struct SplitDetailsView: View {
    @EnvironmentObject var splitsVM: SplitsVM
    var name: String
    var totalAmount : Double
    var body: some View {
        VStack{
            HStack {
                Text(name)
                Text("\(totalAmount)")
            }
            
            ForEach(Array(splitsVM.copyParticipants.enumerated()), id: \.offset) { index, data in
                
                HStack {
                    if data.name != "" && data.name != name {
                        Text(data.name)
                        Text("\(data.expense)")
                    }
                }
            }
        }
    }
}

