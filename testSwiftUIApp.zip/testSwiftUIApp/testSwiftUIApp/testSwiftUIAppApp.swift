//
//  testSwiftUIAppApp.swift
//  testSwiftUIApp
//
//  Created by Rishab Subodh Habbu on 29/02/24.
//

import SwiftUI

@main
struct testSwiftUIAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
