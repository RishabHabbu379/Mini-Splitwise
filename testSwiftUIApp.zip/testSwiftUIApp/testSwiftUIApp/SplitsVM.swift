//
//  SplitsVM.swift
//  testSwiftUIApp
//
//  Created by Rishab Subodh Habbu on 29/02/24.
//

import Foundation
import Combine

class SplitsVM : ObservableObject, Observable {
    @Published var totalTextFields = [String]()
    
    @Published var totalParticipants = [User]()
    
    @Published var copyParticipants = [User]()
    
    @Published var expenseInfo = ""
    @Published var expenseAmount = ""
    
    @Published var payeeName = ""
    
    fileprivate var expense : Double {
        if let amount = Double(expenseAmount) {
            return amount
        }
        return 0
    }
    
    let tabContents = ["Add", "View Balances"]
    let userName = "Rishab"
    
    func addParticipant() {
        totalTextFields.append("")
    }
    
    func updateUserData() {
        totalParticipants.removeAll()
        totalParticipants.append(getPayeeData())
        for field in totalTextFields {
            let user = User(name: field, expense: getDistributedExpense().0)
            totalParticipants.append(user)
            
        }
    }
    
    func getDistributedExpense(share: Int = 1) -> (Double, Double) {
        if let amount = Double(expenseAmount) {
            return (-(amount/Double(totalTextFields.count+1)), amount*(1-1/(Double(totalTextFields.count+1))))
        }
        // Handle with error
        return (0, 0)
    }
    
    func getPayeeData() -> User {
        return User(name: payeeName, expense: getDistributedExpense().1)
    }
    
    func updateViewAllParticipants() {
        copyParticipants = totalParticipants
    }
    
}
